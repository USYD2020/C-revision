#include <stdio.h>

void print_int_array(int* arr, const size_t len) {

	for(size_t i = 0; i < len; i++) {
		printf("%d\n", arr[i]);
	}
	printf("\n");
}

void print_int_array2d(int arr[2][2], const size_t w, const size_t h) {
	for(size_t i = 0; i < w; i++) {
		for(size_t j = 0; j < h; j++) {
			printf("%d\n", arr[i][j]);
		}
	}
	printf("\n");
}

//The difference between a 2d array and nested pointer is that a nested pointer 
//can involve multiple pointers while a 2d array does not.

int main(int argc, char** argv) {

	int array[2] = { 1, 2 };
	int array2d[2][2] = { {1, 2 }, {3, 4} };
	
	print_int_array(array, 2);
	print_int_array(array2d, 4); //works but violates static checks
	print_int_array2d(array2d, 2, 2); //clear
	
	
	return 0;
}
