
#define WIDTH (3)
#define HEIGHT (3)
#define DEPTH (3)

int main() {
	
	//2D Array
	int array_1[WIDTH][HEIGHT] = {
			{1, 2, 3},
			{4, 5, 6},
			{7, 8, 9}
		};
		
	for(int i = 0; i < WIDTH; i++) {
		for(int j = 0; j < HEIGHT; j++) {
			printf("%d\n", array_1[i][j]);
		}
		printf("\n");
	}
	
	
	//2d-1d
	int array_2[WIDTH*HEIGHT] = {
			1, 2, 3,
			4, 5, 6,
			7, 8, 9
		};
	
	for(int i = 0; i < WIDTH; i++) {
		for(int j = 0; j < HEIGHT; j++) {
			printf("%d\n", array_2[(i * WIDTH)+j]);
		}
		printf("\n");
	}
	
	//3d array
	int array_4[WIDTH-1][HEIGHT-1][DEPTH-1] = {
			{ {1, 2}, {3, 4} },
			{ {5, 6}, {7, 8} }
		};
	
	for(int i = 0; i < WIDTH-1; i++) {
		for(int j = 0; j < HEIGHT-1; j++) {
			for(int k = 0; k < DEPTH-1; k++) {
				printf("%d\n", array_4[i][j][k]);
			}
			printf("\n");
		}
		printf("\n");
	}
	
	//3D as 1d
	int array_5[(WIDTH-1)*(HEIGHT-1)*(DEPTH-1)] = {
		1, 2, 3, 4, 5, 6, 7, 8
	};
	
	for(int i = 0; i < WIDTH; i++) {
		for(int j = 0; j < HEIGHT; j++) {
			for(int k = 0; k < DEPTH; k++) {
				printf("%d\n", array_5[(j*(HEIGHT-1))*(i * (WIDTH-1))+k]);
			}
			printf("\n");
		}
		printf("\n");
	}
	
	//2d jagged
	
	int* jagged_array[2];
	jagged_array[0] = { 1, 2, 3 };
	jagged_array[1] = { 4, 5, 6, 7, 8, 9};
	
	for(int i = 0; i < 3; i++) {
		printf("%d\n", jagged_array[0][i]);
	}
	
	for(int i = 0; i < 6; i++) {
		printf("%d\n", jagged_array[1][i]);
	}
}
