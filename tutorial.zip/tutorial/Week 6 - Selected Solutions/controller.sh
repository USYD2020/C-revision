#/bin/bash
gcc gamepad.c -g -fsanitize=address -std=c99 -o gamepad
socat pty,raw,echo=0,link=./controller0 pty,raw,echo=0,link=./device0 &
#socat pipe:./controller0 pipe:./device0 &
echo $! > socat_pid
sleep 1
./gamepad ./device0 30
kill -HUP $(cat socat_pid)
rm socat_pid

