#include <stdio.h>

int main(int argc, char** argv) {
	char name[256];
	fgets(name, 256, stdin);
	printf("%s %s\n", argv[1], name);
	return 0;
}
