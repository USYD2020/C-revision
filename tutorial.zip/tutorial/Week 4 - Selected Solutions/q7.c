#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

void swap_mem(void* a, void* b, const size_t n_bytes) {
	uint8_t* a_ptr = a;
	uint8_t* b_ptr = b;
	
	for(size_t i = 0; i < n_bytes; i++) {
		(a_ptr[i]) ^= (b_ptr[i]);
		(b_ptr[i]) ^= (a_ptr[i]);
		(a_ptr[i]) ^= (b_ptr[i]);
	}

}

int main() {
	int array_1[] = { 1, 2, 3, 4 };
	int array_2[] = { 5, 6, 7, 8 };
	
	swap_mem(array_1, array_2, 16);
	
	for(int i = 0; i < 4; i++) {
		printf("%d %d\n", array_1[i], array_2[i]);
	}
	
}
