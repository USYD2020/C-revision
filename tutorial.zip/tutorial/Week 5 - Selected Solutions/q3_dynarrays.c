#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
	
	if(argc > 1) {
		int n = strtol(argv[1]);
		int* array = malloc(n*sizeof(int));	
		
		for(int i = 0; i < n; i++) {
			array[i] = i*i;
		}
		
		for(int i = 0; i < n-1; i++) {
			printf("%d ", array[i]);
		}
		printf("%d\n", array[n-1]);
		
		free(array);
	}

	return 0;
}
