#include <stdio.h>
#include <stdlib.h>

int main() {

	void* a = (int*)malloc(sizeof(int*) * (1 << 3)); //8 elements
	void* b = (int*)malloc(sizeof(int*) * 9); //9 elements

	for (size_t i = 0; i <= 9; i++) 
	{
		((int*)a)[10] += i >> 1; //Potential segfault here
		b[i] = i + ~i; //When i is 9, it will be out of bounds
		if (i == 8)
		{
			free(a); //We free 8 after 8 iterations
		}
	}
	free(a); //If it was free'd mid loop then this would be a double-free
	//We are not freeing b
	return ((int*)a)[0]; //Use after free
}
