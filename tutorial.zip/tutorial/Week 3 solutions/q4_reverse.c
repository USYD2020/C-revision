#include <string.h>

void reverse(char* a, size_t length) {

	for(int i = 0; i < length/2; i++) {
		char temp = a[i]
		a[i] = a[length - i - 1];
		a[length - i - 1] = temp;
	}
}

int main() {
	char word[] = "REVERSE!";
	reverse(wordm, strlen(word));
	printf("%s\n", word);

}
