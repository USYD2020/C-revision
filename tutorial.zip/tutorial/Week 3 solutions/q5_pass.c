#include <stdlib.h>

#define MAX_PASS (256)

char char_gen() {
	char r_val = 33 + (rand() % 93);
	return r_val;
}

void pass_gen(char* buf, size_t pass_sz) {
	while(pass_sz--) {
		buf[pass_sz] = char_gen();
	}
}

int main(int argc, char** argv) {
	
	char pass_buf[MAX_PASS];
	if(argc > 1) {
		size_t sz = strtol(argv[1], NULL, 10);
		pass_gen(pass_buf, sz);
	} else {
		printf("Please specify a length\n");
	}
	
	return 0;
}
