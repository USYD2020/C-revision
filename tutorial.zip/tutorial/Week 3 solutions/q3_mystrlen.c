#include <stdio.h>
#include <stdlib.h>

size_t c_strlen(char* str) {

	size_t count = 0;
	if(str != NULL) {
		while (*str) {
			count++;
			str++;
		}
	}
	return count;
}		

int main() {
	
	char my_string[] = "Hello this is my string!";
	
	printf("Length of %s is: %lu\n", my_string, c_strlen(my_string));
	
	return 0;
}
