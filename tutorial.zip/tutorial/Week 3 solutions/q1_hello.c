#include <stdio.h>

int main() {
	printf("Hello From C!\n");
	return 0;
}
