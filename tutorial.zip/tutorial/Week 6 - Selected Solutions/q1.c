#include <stdio.h>
#include <unistd.h>

int main() {

	fprintf(stdout, "%s\n", "Hello World!"); //I guess it is printf, however we are using the FILE*
	//dprintf(STDOUT_FILENO, "%s\n", "Hello World!"); //Using the file descriptor
	write(STDOUT_FILENO, "Hello World!\n", sizeof("Hello World!\n")); // Using the file descriptor and sys call
	
	
}
