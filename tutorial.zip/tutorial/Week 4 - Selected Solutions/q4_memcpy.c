#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

void* my_memcpy(void* dest, void* src, size_t n) {
	uint8_t* d_ptr = (uint8_t*) dest;
	uint8_t* s_ptr = (uint8_t*) src;
	for(size_t i = 0; i < n; i++) {
		d_ptr[i] = s_ptr[i];
	}
	return d_ptr;
}


int main() {

	int src_data[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
	int dest_data[10];
	my_memcpy(dest_data, src_data, sizeof(int) * 10);

	for(int i = 0; i < 10; i++) {
		printf("%d ", dest_data[i]);
	}
	printf("\n");

 	return 0;
}
